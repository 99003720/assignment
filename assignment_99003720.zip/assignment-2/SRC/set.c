#include "myutils.h"

int myset(int x)
{
  int number=1;
if(x==0)
{
  number = 1;
}

return number;
}



