#include "mystring.h"
int mystrlen(char *str_input)
{
    int length;
    length = strlen(str_input);
    return length;
}

