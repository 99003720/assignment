#include "bitmask.h"

int myreset(int x)
{
int number=0;
if(x==1)
{
    number = 0;
}
return number;
}
