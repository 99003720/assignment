#include "mystring.h"

int mystrcat(char *s1,char *s2)
{
 strcat(s1,s2);
 printf("%s",s1);
}


