#include<stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isPalindrome(int num);
int isPrime();

long find_factorial(int num);
