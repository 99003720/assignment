#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int myset(int x);
int myreset(int x);
int flip(int num);